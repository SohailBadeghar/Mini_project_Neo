var mainMenu = document.querySelector('.links')
var openMenu = document.querySelector('.open')
var closeMenu = document.querySelector('.close')

openMenu.addEventListener('click', show)
closeMenu.addEventListener('click', close)

function show(){
    mainMenu.style.display = 'flex'
    mainMenu.style.right = '0'
}
function close(){
    mainMenu.style.right = '-60%'
}



function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Read more"; 
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Read less"; 
      moreText.style.display = "inline";
    }
  }

  $(document).ready(function(){
    $("#btn").click(function(){
        $('#para').text( "WORK HARD UNTIL SUCCESS BECOME EASIER TO YOU")
    });
});


